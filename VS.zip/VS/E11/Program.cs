﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Cuantos numeros enteros desea ingresar:");
            int a = int.Parse(Console.ReadLine());
            int[] numeros = new int[a];

            int c = 0;
            int b = 0;
            Console.WriteLine("Ingrese los numeros");
            for (int i = 0; i < a; i++)
            {
                Console.WriteLine($"Numero {i + 1}");
                numeros[i] = int.Parse(Console.ReadLine());
                if ((numeros[i]%2)==0) { c++; } 
                else { b++; }

            }
            Console.WriteLine($"Hubo {c} numeros pares y {b} numeros impares");
            Console.ReadKey();
        }
    }
}
