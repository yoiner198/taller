﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace E4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite el valor de x");
            double x = double.Parse(Console.ReadLine());
            if(x<=0)
            {
                Console.WriteLine("El valor de f(x) es 0 ");

            }
            else
            {
                x = Math.Pow(x, 2);
                Console.WriteLine($"El valor de f(x) es {x}");
            }
            Console.ReadKey();
        }
    }
}
