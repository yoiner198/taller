﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] notas = new double[10];
            int a = 0;
            int b = 0;
            Console.WriteLine("Ingrese las notas, solo valores de 0 hasta 10");

            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Nota {i+1}");
                notas[i] = double.Parse( Console.ReadLine() );
                if (notas[i] >= 7) { a++; }
                else { b++; }
            }
            Console.WriteLine($"la cantidad de notas mayores o iguales a 7 fue de: {a}, y la de notas menores a 7 fue de: {b}");
            Console.ReadKey();
        }
    }
}
